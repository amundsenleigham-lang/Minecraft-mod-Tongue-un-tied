package dev.speakorlose;

import dev.speakorlose.net.ChallengePayload;
import dev.speakorlose.net.ResultPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SpeakOrLose implements ModInitializer {
	public static final String MOD_ID = "speakorlose";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		PayloadTypeRegistry.clientboundPlay().register(ChallengePayload.TYPE, ChallengePayload.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(ResultPayload.TYPE, ResultPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(ResultPayload.TYPE,
				(payload, context) -> ChallengeManager.onResult(context.player(), payload));

		ServerLifecycleEvents.SERVER_STARTING.register(server -> ChallengeManager.reloadConfig());
		ServerLifecycleEvents.SERVER_STARTED.register(ChallengeManager::onServerStarted);
		ServerLifecycleEvents.SERVER_STOPPING.register(ChallengeManager::onServerStopping);
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> ChallengeManager.onJoin(handler.player));
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> ChallengeManager.onLeave(handler.player));
		ServerTickEvents.END_SERVER_TICK.register(ChallengeManager::onServerTick);
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
