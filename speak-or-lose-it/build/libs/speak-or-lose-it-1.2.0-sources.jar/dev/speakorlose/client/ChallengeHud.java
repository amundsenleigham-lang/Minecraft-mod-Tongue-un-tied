package dev.speakorlose.client;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Draws the challenge card at the top-centre of the screen. */
final class ChallengeHud {
	private static final int BG = 0xD0101418;
	private static final int ACCENT = 0xFF2EC4B6;   // teal
	private static final int PASS = 0xFF7BE07B;
	private static final int FAIL = 0xFFFF6B6B;
	private static final int MUTED = 0xFFAAB4BE;
	private static final int WHITE = 0xFFFFFFFF;
	private static final long RESULT_SHOW_MS = 2500;

	private ChallengeHud() {}

	static void extract(GuiGraphicsExtractor g, DeltaTracker delta) {
		drawDownloadStatus(g);
		SpeakOrLoseClient.ActiveChallenge c = SpeakOrLoseClient.current;
		if (c == null) return;
		if (c.finishedAt > 0 && System.currentTimeMillis() - c.finishedAt > RESULT_SHOW_MS) {
			if (SpeakOrLoseClient.current == c) SpeakOrLoseClient.current = null;
			return;
		}

		Font font = Minecraft.getInstance().font;
		int cx = g.guiWidth() / 2;
		int w = Math.max(180, font.width(c.target) * 2 + 24);
		int left = cx - w / 2, right = cx + w / 2, top = 6, bottom = 62;

		g.fill(left, top, right, bottom, BG);
		g.fill(left, top, left + 2, bottom, ACCENT);

		g.text(font, "SPEAK OR LOSE IT · " + Translations.languageName(c.payload.language()).toUpperCase(), left + 8, top + 5, ACCENT);

		// Target word, drawn at 2x.
		g.pose().pushMatrix();
		g.pose().translate(cx - font.width(c.target), top + 17);
		g.pose().scale(2f, 2f);
		g.text(font, c.target, 0, 0, WHITE, true);
		g.pose().popMatrix();

		String status;
		int statusColor;
		switch (c.state) {
			case PASSED -> { status = "KEPT · " + pct(c.liveScore); statusColor = PASS; }
			case FAILED -> { status = "LOST · " + pct(c.liveScore); statusColor = FAIL; }
			case NO_MODEL -> { status = "No speech model for " + c.payload.language() + " (skipped)"; statusColor = MUTED; }
			case NO_MIC -> { status = "Microphone unavailable (skipped)"; statusColor = MUTED; }
			case GET_READY -> { status = "Get ready…"; statusColor = MUTED; }
			case DOWNLOADING -> { status = "Downloading speech model… (skipped this time)"; statusColor = MUTED; }
			default -> {
				status = c.heard.isBlank() ? "Speak now!" : "heard: " + c.heard + "  " + pct(c.liveScore);
				statusColor = MUTED;
			}
		}
		g.text(font, font.plainSubstrByWidth(status, w - 16), left + 8, top + 40, statusColor);

		// Time bar.
		float total = c.payload.seconds() * 1000f;
		long elapsed = c.state == SpeakOrLoseClient.ActiveChallenge.State.GET_READY ? 0
				: (c.finishedAt > 0 ? c.finishedAt : System.currentTimeMillis()) - c.startedAt;
		float frac = Math.clamp(1f - elapsed / total, 0f, 1f);
		int barColor = c.state == SpeakOrLoseClient.ActiveChallenge.State.FAILED ? FAIL
				: c.state == SpeakOrLoseClient.ActiveChallenge.State.PASSED ? PASS : ACCENT;
		g.fill(left + 8, bottom - 6, right - 8, bottom - 4, 0x40FFFFFF);
		g.fill(left + 8, bottom - 6, left + 8 + Math.round((w - 16) * frac), bottom - 4, barColor);

		// Mic level meter on the right edge, so players can see the mic is actually hearing them.
		if (c.state == SpeakOrLoseClient.ActiveChallenge.State.LISTENING) {
			int meterTop = top + 6, meterBottom = bottom - 10;
			int h = meterBottom - meterTop;
			int filled = Math.round(h * Math.clamp(SpeechListener.level, 0f, 1f));
			g.fill(right - 8, meterTop, right - 5, meterBottom, 0x40FFFFFF);
			g.fill(right - 8, meterBottom - filled, right - 5, meterBottom, PASS);
		}
	}

	/** Small line in the top-left while a model downloads, or after one fails. */
	private static void drawDownloadStatus(GuiGraphicsExtractor g) {
		Font font = Minecraft.getInstance().font;
		String lang = ModelInstaller.downloading;
		if (lang != null) {
			float p = ModelInstaller.progress;
			String text = "Downloading " + Translations.languageName(lang) + " speech model" + (p >= 0 ? " " + pct(p) : "…");
			g.fill(2, 2, 10 + font.width(text), 14, BG);
			g.text(font, text, 6, 4, ACCENT);
		} else if (ModelInstaller.lastError != null) {
			String text = ModelInstaller.lastError;
			g.fill(2, 2, 10 + font.width(text), 14, BG);
			g.text(font, text, 6, 4, FAIL);
		}
	}

	private static String pct(float score) {
		return Math.round(score * 100) + "%";
	}
}
