package dev.speakorlose.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.speakorlose.SpeakOrLose;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Duration;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Gets speech models onto disk: unpacks the ones bundled in the jar, and downloads
 * the rest from alphacephei.com (the Vosk project) on demand.
 */
public final class ModelInstaller {

	/** Known small Vosk models per Minecraft language code. All Apache-2.0 licensed. */
	private static final Map<String, String> DEFAULT_MODELS = Map.ofEntries(
			Map.entry("de_de", "vosk-model-small-de-0.15"),
			Map.entry("es_es", "vosk-model-small-es-0.42"),
			Map.entry("es_mx", "vosk-model-small-es-0.42"),
			Map.entry("es_ar", "vosk-model-small-es-0.42"),
			Map.entry("fr_fr", "vosk-model-small-fr-0.22"),
			Map.entry("fr_ca", "vosk-model-small-fr-0.22"),
			Map.entry("it_it", "vosk-model-small-it-0.22"),
			Map.entry("pt_br", "vosk-model-small-pt-0.3"),
			Map.entry("pt_pt", "vosk-model-small-pt-0.3"),
			Map.entry("ja_jp", "vosk-model-small-ja-0.22"),
			Map.entry("ru_ru", "vosk-model-small-ru-0.22")
	);
	/** Large models: far more accurate, 1–2 GB each. Apache-2.0 only (Portuguese large is GPL, so it stays small). */
	private static final Map<String, String> LARGE_MODELS = Map.ofEntries(
			Map.entry("de_de", "vosk-model-de-0.21"),
			Map.entry("es_es", "vosk-model-es-0.42"),
			Map.entry("es_mx", "vosk-model-es-0.42"),
			Map.entry("es_ar", "vosk-model-es-0.42"),
			Map.entry("fr_fr", "vosk-model-fr-0.22"),
			Map.entry("fr_ca", "vosk-model-fr-0.22"),
			Map.entry("it_it", "vosk-model-it-0.22"),
			Map.entry("ja_jp", "vosk-model-ja-0.22"),
			Map.entry("ru_ru", "vosk-model-ru-0.42")
	);
	private static final String BASE_URL = "https://alphacephei.com/vosk/models/";
	private static final String BUNDLE_DIR = "/speakorlose_models/";

	private static final ExecutorService DOWNLOADS = Executors.newSingleThreadExecutor(r -> {
		Thread t = new Thread(r, "SpeakOrLose-ModelDownload");
		t.setDaemon(true);
		return t;
	});

	/** Language currently downloading, or null. Read by the HUD. */
	public static volatile String downloading;
	/** 0..1, or -1 when the size is unknown. */
	public static volatile float progress;
	/** Last download failure message for the HUD, or null. */
	public static volatile String lastError;

	private static ClientConfig config;

	private ModelInstaller() {}

	// ---------------------------------------------------------------- bundled

	public static boolean isBundled(String language) {
		return ModelInstaller.class.getResource(BUNDLE_DIR + language + ".zip") != null;
	}

	/** Unpack every bundled model that isn't on disk yet. Call from a background thread. */
	public static void extractAllBundled() {
		for (String language : DEFAULT_MODELS.keySet()) {
			if (isBundled(language)) ensureBundled(language);
		}
	}

	/** Unpack the bundled model for this language if needed. Returns true if it is now on disk. */
	public static synchronized boolean ensureBundled(String language) {
		if (Files.isDirectory(SpeechListener.modelDir(language))) return true;
		try (InputStream in = ModelInstaller.class.getResourceAsStream(BUNDLE_DIR + language + ".zip")) {
			if (in == null) return false;
			SpeakOrLose.LOGGER.info("Unpacking bundled speech model for {}", language);
			unzipInto(in, SpeechListener.modelDir(language));
			return true;
		} catch (IOException e) {
			SpeakOrLose.LOGGER.error("Could not unpack bundled speech model for {}", language, e);
			return false;
		}
	}

	// --------------------------------------------------------------- download

	/** True if a large model was chosen and exists for this language but isn't installed yet. */
	public static boolean largeMissing(String language) {
		return SpeechListener.wantsLarge() && LARGE_MODELS.containsKey(language)
				&& !Files.isDirectory(SpeechListener.largeModelDir(language));
	}

	public static boolean hasLarge(String language) {
		return LARGE_MODELS.containsKey(language);
	}

	public static boolean canDownload(String language) {
		return config().autoDownloadModels && (largeMissing(language) || DEFAULT_MODELS.containsKey(language));
	}

	/**
	 * Start a background download if one isn't already running: the large model if it's chosen and
	 * missing, otherwise the small model if that's missing.
	 */
	public static synchronized void requestDownload(String language) {
		if (downloading != null || !config().autoDownloadModels) return;
		final String name;
		final Path target;
		if (largeMissing(language)) {
			name = LARGE_MODELS.get(language);
			target = SpeechListener.largeModelDir(language);
		} else if (!Files.isDirectory(SpeechListener.modelDir(language)) && modelName(language) != null) {
			name = modelName(language);
			target = SpeechListener.modelDir(language);
		} else {
			return;
		}
		downloading = language;
		progress = 0f;
		lastError = null;
		DOWNLOADS.execute(() -> {
			try {
				download(language, name, target);
				SpeechListener.preload(language);
			} catch (Exception e) {
				SpeakOrLose.LOGGER.error("Speech model download for {} failed", language, e);
				lastError = "Couldn't download " + Translations.languageName(language) + " speech model";
			} finally {
				downloading = null;
			}
		});
	}

	private static void download(String language, String name, Path target) throws IOException, InterruptedException {
		Path dir = SpeechListener.modelsDir();
		Files.createDirectories(dir);
		Path tmp = dir.resolve(language + ".zip.part");
		URI uri = URI.create(BASE_URL + name + ".zip");
		SpeakOrLose.LOGGER.info("Downloading speech model {}", uri);

		HttpClient client = HttpClient.newBuilder()
				.followRedirects(HttpClient.Redirect.NORMAL)
				.connectTimeout(Duration.ofSeconds(20))
				.build();
		HttpResponse<InputStream> response = client.send(
				HttpRequest.newBuilder(uri).header("User-Agent", "SpeakOrLoseIt-Minecraft-Mod").GET().build(),
				HttpResponse.BodyHandlers.ofInputStream());
		if (response.statusCode() != 200) throw new IOException("HTTP " + response.statusCode());

		long total = response.headers().firstValueAsLong("Content-Length").orElse(-1);
		try (InputStream in = response.body(); OutputStream out = Files.newOutputStream(tmp)) {
			byte[] buf = new byte[64 * 1024];
			long done = 0;
			int n;
			while ((n = in.read(buf)) > 0) {
				out.write(buf, 0, n);
				done += n;
				progress = total > 0 ? (float) done / total : -1f;
			}
		}

		try (InputStream in = Files.newInputStream(tmp)) {
			unzipInto(in, target);
		} finally {
			Files.deleteIfExists(tmp);
		}
		SpeakOrLose.LOGGER.info("Installed speech model for {}", language);
	}

	private static String modelName(String language) {
		String override = config().modelOverrides.get(language);
		return override != null && !override.isBlank() ? override : DEFAULT_MODELS.get(language);
	}

	// ------------------------------------------------------------------ unzip

	/** Unzips into a temp folder first, then moves it into place so a half-finished model is never used. */
	private static void unzipInto(InputStream zipStream, Path target) throws IOException {
		Path staging = target.resolveSibling(target.getFileName() + ".installing");
		deleteTree(staging);
		Files.createDirectories(staging);
		try (ZipInputStream zip = new ZipInputStream(zipStream)) {
			ZipEntry entry;
			while ((entry = zip.getNextEntry()) != null) {
				Path out = staging.resolve(entry.getName()).normalize();
				if (!out.startsWith(staging)) throw new IOException("Bad zip entry: " + entry.getName());
				if (entry.isDirectory()) {
					Files.createDirectories(out);
				} else {
					Files.createDirectories(out.getParent());
					Files.copy(zip, out, StandardCopyOption.REPLACE_EXISTING);
				}
			}
		} catch (IOException e) {
			deleteTree(staging);
			throw e;
		}
		deleteTree(target);
		Files.move(staging, target, StandardCopyOption.ATOMIC_MOVE);
	}

	private static void deleteTree(Path dir) throws IOException {
		if (!Files.exists(dir)) return;
		try (Stream<Path> walk = Files.walk(dir)) {
			for (Path p : walk.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(p);
		}
	}

	// ----------------------------------------------------------------- config

	/** Client-only settings in config/speakorlose-client.json. */
	public static final class ClientConfig {
		/** Download missing speech models from alphacephei.com automatically. */
		public boolean autoDownloadModels = true;
		/** Input device name, or "" for the system default microphone. */
		public String microphone = "";
		/** "small" (fast, ~50 MB) or "large" (much more accurate, 1–2 GB download). */
		public String modelQuality = "small";
		/** Filter out hum and automatically raise quiet microphones. */
		public boolean micBoost = true;
		/** Use a different Vosk model for a language, e.g. {"de_de": "vosk-model-de-0.21"} for the large one. */
		public Map<String, String> modelOverrides = new HashMap<>();
	}

	private static Path clientConfigPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("speakorlose-client.json");
	}

	public static synchronized void saveClientConfig() {
		try (Writer w = Files.newBufferedWriter(clientConfigPath())) {
			new GsonBuilder().setPrettyPrinting().create().toJson(config(), w);
		} catch (Exception e) {
			SpeakOrLose.LOGGER.error("Could not save {}", clientConfigPath(), e);
		}
	}

	/** Languages with a known model (shown in the settings screen). */
	public static java.util.List<String> knownLanguages() {
		return DEFAULT_MODELS.keySet().stream().sorted().toList();
	}

	public static synchronized ClientConfig config() {
		if (config != null) return config;
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		Path path = clientConfigPath();
		ClientConfig loaded = new ClientConfig();
		try {
			if (Files.exists(path)) {
				try (Reader r = Files.newBufferedReader(path)) {
					ClientConfig read = gson.fromJson(r, ClientConfig.class);
					if (read != null) loaded = read;
				}
			}
			if (loaded.modelOverrides == null) loaded.modelOverrides = new HashMap<>();
			if (loaded.microphone == null) loaded.microphone = "";
			if (!"large".equals(loaded.modelQuality)) loaded.modelQuality = "small";
			try (Writer w = Files.newBufferedWriter(path)) {
				gson.toJson(loaded, w);
			}
		} catch (Exception e) {
			SpeakOrLose.LOGGER.error("Could not read {}", path, e);
		}
		config = loaded;
		return config;
	}
}
