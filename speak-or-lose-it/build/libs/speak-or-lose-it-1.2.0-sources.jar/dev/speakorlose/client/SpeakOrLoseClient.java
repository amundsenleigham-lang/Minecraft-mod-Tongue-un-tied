package dev.speakorlose.client;

import dev.speakorlose.SpeakOrLose;
import dev.speakorlose.net.ChallengePayload;
import dev.speakorlose.net.ResultPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;

public class SpeakOrLoseClient implements ClientModInitializer {

	/** The challenge currently shown on screen, or null. Only touched on the render/main thread. */
	static volatile ActiveChallenge current;

	@Override
	public void onInitializeClient() {
		try {
			Files.createDirectories(SpeechListener.modelsDir());
		} catch (Exception e) {
			SpeakOrLose.LOGGER.warn("Could not create {}", SpeechListener.modelsDir(), e);
		}

		// Unpack bundled models in the background so the first challenge doesn't wait.
		Thread unpack = new Thread(ModelInstaller::extractAllBundled, "SpeakOrLose-Unpack");
		unpack.setDaemon(true);
		unpack.start();

		ClientPlayNetworking.registerGlobalReceiver(ChallengePayload.TYPE, (payload, context) -> begin(payload));
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> current = null);
		// Load speech models as soon as you join, so the first challenge starts instantly.
		ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
			for (String lang : dev.speakorlose.ModConfig.load().languages) {
				if (SpeechListener.hasModel(lang) || ModelInstaller.isBundled(lang)) SpeechListener.preload(lang);
			}
		});

		HudElementRegistry.addLast(SpeakOrLose.id("challenge"), ChallengeHud::extract);

		// Add a "Speak or Lose It..." button to the vanilla Options screen (also reachable from the pause menu).
		ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
			if (screen instanceof OptionsScreen) {
				Screens.getWidgets(screen).add(Button.builder(Component.literal("Speak or Lose It..."),
								b -> client.gui.setScreen(new SettingsScreen(screen)))
						.pos(6, 6).size(110, 20)
						.build());
			}
		});
	}

	private static void begin(ChallengePayload payload) {
		String target = Translations.get(payload.language(), payload.translationKey());
		if (target == null || target.isBlank()) {
			// This language has no name for the item: skip without penalty.
			ClientPlayNetworking.send(new ResultPayload(payload.id(), ResultPayload.SKIPPED, ""));
			return;
		}

		ActiveChallenge challenge = new ActiveChallenge(payload, target);
		current = challenge;

		String lang = payload.language();
		if (!SpeechListener.hasModel(lang) && !ModelInstaller.isBundled(lang)) {
			// Not installed and not bundled: fetch it in the background and skip this one, no penalty.
			if (ModelInstaller.canDownload(lang)) {
				ModelInstaller.requestDownload(lang);
				challenge.state = ActiveChallenge.State.DOWNLOADING;
			} else {
				challenge.state = ActiveChallenge.State.NO_MODEL;
			}
			challenge.finishedAt = System.currentTimeMillis();
			ClientPlayNetworking.send(new ResultPayload(payload.id(), ResultPayload.SKIPPED, ""));
			return;
		}

		// Large model chosen but not downloaded yet: fetch it in the background, use the small one meanwhile.
		if (ModelInstaller.largeMissing(lang)) ModelInstaller.requestDownload(lang);

		double threshold = payload.threshold();
		SpeechListener.listen(lang, payload.seconds() * 1000L,
				heard -> Scoring.score(target, heard),
				threshold,
				new SpeechListener.Listener() {
					@Override
					public void onStart() {
						challenge.startedAt = System.currentTimeMillis();
						challenge.state = ActiveChallenge.State.LISTENING;
					}

					@Override
					public void onLive(String text, double bestScore) {
						challenge.heard = text;
						challenge.liveScore = (float) bestScore;
					}

					@Override
					public void onFinish(SpeechListener.Outcome outcome, String bestHeard, double bestScore) {
						Minecraft.getInstance().execute(() -> finish(challenge, outcome, bestHeard, (float) bestScore));
					}
				});
	}

	private static void finish(ActiveChallenge challenge, SpeechListener.Outcome outcome, String heard, float bestScore) {
		float score;
		switch (outcome) {
			case DONE -> {
				score = bestScore;
				challenge.state = score >= challenge.payload.threshold() ? ActiveChallenge.State.PASSED : ActiveChallenge.State.FAILED;
			}
			case NO_MODEL -> {
				score = ResultPayload.SKIPPED;
				challenge.state = ActiveChallenge.State.NO_MODEL;
			}
			default -> {
				score = ResultPayload.SKIPPED;
				challenge.state = ActiveChallenge.State.NO_MIC;
			}
		}
		challenge.heard = heard;
		challenge.liveScore = Math.max(score, 0f);
		challenge.finishedAt = System.currentTimeMillis();
		if (ClientPlayNetworking.canSend(ResultPayload.TYPE)) {
			ClientPlayNetworking.send(new ResultPayload(challenge.payload.id(), score, heard));
		}
	}

	/** Mutable view-model for the HUD. */
	static final class ActiveChallenge {
		enum State { GET_READY, LISTENING, PASSED, FAILED, NO_MODEL, NO_MIC, DOWNLOADING }

		final ChallengePayload payload;
		final String target;
		/** When the mic went live; the countdown runs from here. */
		volatile long startedAt = System.currentTimeMillis();
		volatile String heard = "";
		volatile float liveScore = 0f;
		volatile State state = State.GET_READY;
		volatile long finishedAt = 0;

		ActiveChallenge(ChallengePayload payload, String target) {
			this.payload = payload;
			this.target = target;
		}
	}
}
