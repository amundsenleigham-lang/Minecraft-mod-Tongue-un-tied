package dev.speakorlose.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.speakorlose.SpeakOrLose;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;

import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

/**
 * Looks up item names in any language using the language files the game client already has,
 * so the mod never ships or copies Mojang's translations.
 */
public final class Translations {
	private static final Map<String, Map<String, String>> CACHE = new HashMap<>();

	private Translations() {}

	public static String get(String language, String key) {
		return CACHE.computeIfAbsent(language, Translations::load).get(key);
	}

	public static void clear() {
		CACHE.clear();
	}

	private static Map<String, String> load(String language) {
		Map<String, String> map = new HashMap<>();
		Identifier file = Identifier.withDefaultNamespace("lang/" + language + ".json");
		try {
			for (Resource resource : Minecraft.getInstance().getResourceManager().getResourceStack(file)) {
				try (Reader reader = resource.openAsReader()) {
					JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
					for (Map.Entry<String, JsonElement> e : json.entrySet()) {
						if (e.getValue().isJsonPrimitive()) map.put(e.getKey(), e.getValue().getAsString());
					}
				}
			}
		} catch (Exception e) {
			SpeakOrLose.LOGGER.error("Could not load Minecraft language file {}", file, e);
		}
		if (map.isEmpty()) SpeakOrLose.LOGGER.warn("No translations found for language '{}'", language);
		return map;
	}

	/** Human-readable name for the HUD header. */
	public static String languageName(String code) {
		return switch (code) {
			case "de_de" -> "German";
			case "es_es", "es_mx", "es_ar" -> "Spanish";
			case "fr_fr", "fr_ca" -> "French";
			case "it_it" -> "Italian";
			case "pt_br", "pt_pt" -> "Portuguese";
			case "ja_jp" -> "Japanese";
			case "ko_kr" -> "Korean";
			case "zh_cn", "zh_tw" -> "Chinese";
			case "ru_ru" -> "Russian";
			case "nl_nl" -> "Dutch";
			case "pl_pl" -> "Polish";
			case "tr_tr" -> "Turkish";
			case "sv_se" -> "Swedish";
			case "uk_ua" -> "Ukrainian";
			case "vi_vn" -> "Vietnamese";
			case "hi_in" -> "Hindi";
			default -> code.toUpperCase();
		};
	}
}
