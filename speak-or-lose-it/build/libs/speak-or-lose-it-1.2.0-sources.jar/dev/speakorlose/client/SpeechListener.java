package dev.speakorlose.client;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.speakorlose.SpeakOrLose;
import net.fabricmc.loader.api.FabricLoader;
import org.vosk.LibVosk;
import org.vosk.LogLevel;
import org.vosk.Model;
import org.vosk.Recognizer;

import javax.sound.sampled.TargetDataLine;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.ToDoubleFunction;

/**
 * Records the microphone on a background thread and runs Vosk offline speech recognition.
 *
 * Models live in config/speakorlose/models/:
 *   &lt;lang&gt;/        small model (bundled or auto-downloaded)
 *   &lt;lang&gt;-large/  large model, used when "Model quality: Large" is selected and it's installed
 */
public final class SpeechListener {
	/** How many alternative transcriptions to ask Vosk for. The best-matching one counts. */
	private static final int ALTERNATIVES = 5;

	/** Current microphone loudness 0..1 while listening, for the level meters. */
	public static volatile float level;

	private static final Map<String, Model> MODELS = new HashMap<>();
	private static final AtomicInteger SESSION = new AtomicInteger();
	private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(r -> {
		Thread t = new Thread(r, "SpeakOrLose-Speech");
		t.setDaemon(true);
		return t;
	});
	private static boolean voskReady;

	private SpeechListener() {}

	// ----------------------------------------------------------------- model locations

	public static Path modelsDir() {
		return FabricLoader.getInstance().getConfigDir().resolve("speakorlose").resolve("models");
	}

	/** Folder for the small model. */
	public static Path modelDir(String language) {
		return modelsDir().resolve(language);
	}

	/** Folder for the large model. */
	public static Path largeModelDir(String language) {
		return modelsDir().resolve(language + "-large");
	}

	public static boolean wantsLarge() {
		return "large".equals(ModelInstaller.config().modelQuality);
	}

	/** The folder that will actually be used right now: large if chosen and installed, else small. */
	public static Path activeModelDir(String language) {
		if (wantsLarge() && Files.isDirectory(largeModelDir(language))) return largeModelDir(language);
		return modelDir(language);
	}

	/** True if any usable model (small or large) is on disk for this language. */
	public static boolean hasModel(String language) {
		return Files.isDirectory(activeModelDir(language));
	}

	// ----------------------------------------------------------------------- listening

	public enum Outcome { DONE, NO_MODEL, NO_MIC, ERROR }

	/** Callbacks for one listen. All run on the speech thread. */
	public interface Listener {
		/** The microphone is live; start the countdown now. */
		default void onStart() {}
		/** Live text and the best score so far. */
		default void onLive(String text, double bestScore) {}
		/** Finished: outcome, the best-matching thing heard, and its score (0 if no scorer). */
		void onFinish(Outcome outcome, String bestHeard, double bestScore);
	}

	/**
	 * Listen for up to {@code millis} after the microphone opens.
	 *
	 * @param scorer    scores a candidate transcription 0..1; every partial result and every
	 *                  alternative is scored and the best one is kept. May be null (mic test).
	 * @param stopAt    stop as soon as a candidate scores at least this (use &gt; 1 to never stop early)
	 */
	public static void listen(String language, long millis, ToDoubleFunction<String> scorer, double stopAt, Listener listener) {
		EXECUTOR.execute(() -> {
			Model model;
			try {
				model = model(language);
			} catch (Throwable t) {
				SpeakOrLose.LOGGER.error("Could not load speech model for {}", language, t);
				listener.onFinish(Outcome.ERROR, "", 0);
				return;
			}
			if (model == null) {
				listener.onFinish(Outcome.NO_MODEL, "", 0);
				return;
			}

			Microphone.Opened mic = Microphone.open(ModelInstaller.config().microphone);
			if (mic == null) {
				listener.onFinish(Outcome.NO_MIC, "", 0);
				return;
			}
			TargetDataLine line = mic.line();
			int session = SESSION.get();
			AudioCleanup cleanup = new AudioCleanup(mic.sampleRate(), ModelInstaller.config().micBoost);

			Best best = new Best(scorer);
			try (Recognizer recognizer = new Recognizer(model, mic.sampleRate())) {
				recognizer.setMaxAlternatives(ALTERNATIVES);
				line.flush();
				line.start();
				listener.onStart();

				// ~100 ms per read keeps the HUD responsive.
				int bytesPerRead = Math.max(2048, (int) (mic.sampleRate() * mic.channels() * 2 / 10)) & ~3;
				byte[] buffer = new byte[bytesPerRead];
				long end = System.currentTimeMillis() + millis;
				StringBuilder finished = new StringBuilder();

				while (System.currentTimeMillis() < end && SESSION.get() == session) {
					int n = line.read(buffer, 0, buffer.length);
					if (n <= 0) continue;
					if (mic.channels() == 2) n = Microphone.toMono(buffer, n);
					cleanup.process(buffer, n);
					level = Microphone.level(buffer, n);

					String live;
					if (recognizer.acceptWaveForm(buffer, n)) {
						List<String> alts = texts(recognizer.getResult());
						String prefix = finished.toString();
						for (String alt : alts) best.offer((prefix + " " + alt).trim());
						if (!alts.isEmpty() && !alts.get(0).isBlank()) {
							finished.append(finished.isEmpty() ? "" : " ").append(alts.get(0));
						}
						live = finished.toString();
					} else {
						String partial = partial(recognizer.getPartialResult());
						live = (finished + " " + partial).trim();
						best.offer(live);
					}
					if (!live.isBlank()) listener.onLive(live, best.score);
					if (best.score >= stopAt) break;
				}

				String prefix = finished.toString();
				for (String alt : texts(recognizer.getFinalResult())) best.offer((prefix + " " + alt).trim());
				if (best.text.isBlank()) best.text = prefix;
			} catch (Throwable t) {
				SpeakOrLose.LOGGER.error("Speech recognition failed", t);
				listener.onFinish(Outcome.ERROR, best.text, best.score);
				return;
			} finally {
				level = 0f;
				line.stop();
				line.close();
			}
			listener.onFinish(Outcome.DONE, best.text, best.score);
		});
	}

	/** Stop the current listen early (e.g. the mic test screen was closed). */
	public static void cancel() {
		SESSION.incrementAndGet();
	}

	/** Load a model in the background so the first challenge doesn't stall. */
	public static void preload(String language) {
		EXECUTOR.execute(() -> {
			try {
				model(language);
			} catch (Throwable t) {
				SpeakOrLose.LOGGER.error("Could not preload speech model for {}", language, t);
			}
		});
	}

	/** Tracks the best-scoring transcription seen during one listen. */
	private static final class Best {
		final ToDoubleFunction<String> scorer;
		String text = "";
		double score = 0;

		Best(ToDoubleFunction<String> scorer) {
			this.scorer = scorer;
		}

		void offer(String candidate) {
			if (candidate == null || candidate.isBlank()) return;
			if (scorer == null) {
				text = candidate;
				return;
			}
			double s = scorer.applyAsDouble(candidate);
			if (s > score || text.isBlank()) {
				score = Math.max(score, s);
				text = candidate;
			}
		}
	}

	// --------------------------------------------------------------------------- vosk

	private static synchronized Model model(String language) throws Exception {
		if (!hasModel(language) && !ModelInstaller.ensureBundled(language)) return null;
		Path dir = activeModelDir(language);
		// Accept either <dir>/<model files> or <dir>/vosk-model-xyz/<model files>.
		if (!Files.isDirectory(dir.resolve("am")) && !Files.exists(dir.resolve("conf"))) {
			try (var children = Files.list(dir)) {
				dir = children.filter(Files::isDirectory).findFirst().orElse(dir);
			}
		}
		String key = dir.toAbsolutePath().toString();
		if (MODELS.containsKey(key)) return MODELS.get(key);
		if (!voskReady) {
			LibVosk.setLogLevel(LogLevel.WARNINGS);
			voskReady = true;
		}
		SpeakOrLose.LOGGER.info("Loading speech model {}", dir);
		Model model = new Model(key);
		MODELS.put(key, model);
		return model;
	}

	/** Text from a result. With alternatives enabled Vosk returns {"alternatives":[{"text":...},...]}. */
	private static List<String> texts(String json) {
		List<String> out = new ArrayList<>();
		try {
			JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
			if (obj.has("alternatives")) {
				for (JsonElement e : obj.getAsJsonArray("alternatives")) {
					JsonObject alt = e.getAsJsonObject();
					if (alt.has("text")) out.add(alt.get("text").getAsString().trim());
				}
			} else if (obj.has("text")) {
				out.add(obj.get("text").getAsString().trim());
			}
		} catch (Exception ignored) {
		}
		return out;
	}

	private static String partial(String json) {
		try {
			JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
			return obj.has("partial") ? obj.get("partial").getAsString().trim() : "";
		} catch (Exception e) {
			return "";
		}
	}
}
