package dev.speakorlose.client;

import dev.speakorlose.ChallengeManager;
import dev.speakorlose.ModConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntFunction;
import java.util.function.Supplier;

/**
 * In-game settings, built only from vanilla widgets so it looks like the normal Options menu.
 * Gameplay settings are editable from the title screen and in singleplayer (applied live).
 * On a multiplayer server they are read-only, because the server's own config file decides them.
 */
public class SettingsScreen extends Screen {
	private static final int BUTTON_W = 150;
	private static final int BUTTON_H = 20;
	private static final int GAP = 4;
	private static final int ROW = BUTTON_H + GAP;
	private static final int HEADER_COLOR = 0xFFFFFFFF;
	private static final int NOTE_COLOR = 0xFFA0A0A0;

	private final Screen parent;
	private final ModConfig config;
	private final boolean serverEditable;
	private EditBox ignoredBox;
	private int gameplayLabelY;
	private int clientLabelY;

	public SettingsScreen(Screen parent) {
		super(Component.literal("Speak or Lose It"));
		this.parent = parent;
		this.config = ModConfig.load();
		Minecraft mc = Minecraft.getInstance();
		// Editable when not connected anywhere (title screen) or when playing our own world.
		this.serverEditable = mc.level == null || mc.hasSingleplayerServer();
	}

	@Override
	protected void init() {
		int left = this.width / 2 - BUTTON_W - GAP / 2;
		int right = this.width / 2 + GAP / 2;
		int y = 26;

		gameplayLabelY = y;
		y += 12;

		List<Button> gameplay = new ArrayList<>();

		// Row 1
		gameplay.add(languagesButton = addRenderableWidget(Button.builder(languagesLabel(), b ->
				this.minecraft.gui.setScreen(new LanguagesScreen(this, config, this::refreshLanguages)))
				.pos(left, y).size(BUTTON_W, BUTTON_H)
				.tooltip(Tooltip.create(Component.literal("Which languages challenges use. One is picked at random each time.")))
				.build()));
		gameplay.add(cycle(right, y, "Delete on fail", List.of("all", "stack", "one"),
				() -> config.deleteMode, v -> config.deleteMode = v,
				v -> switch (v) { case "stack" -> "One stack"; case "one" -> "One item"; default -> "All of it"; },
				"What you lose when you mispronounce an item."));
		y += ROW;

		// Row 2
		addSlider(gameplay, left, y, "Time to answer", 2, 30, 1,
				() -> config.answerSeconds, v -> config.answerSeconds = v, v -> v + "s",
				"Seconds you get to say the word.");
		addSlider(gameplay, right, y, "Accuracy needed", 30, 100, 5,
				() -> Math.round(config.passThreshold * 100), v -> config.passThreshold = v / 100f, v -> v + "%",
				"How close your pronunciation must be to unlock the item.");
		y += ROW;

		// Row 3
		gameplay.add(toggle(left, y, "Random review", () -> config.triggerOnTimer, v -> config.triggerOnTimer = v,
				"Every so often, quiz a random item from your inventory, even unlocked ones. Failing re-locks it."));
		addSlider(gameplay, right, y, "Review every", 10, 600, 10,
				() -> config.timerSeconds, v -> config.timerSeconds = v, v -> v + "s",
				"How often a random review happens.");
		y += ROW;

		// Row 4
		addSlider(gameplay, left, y, "Retry delay", 1, 60, 1,
				() -> config.retryDelaySeconds, v -> config.retryDelaySeconds = v, v -> v + "s",
				"After a challenge, wait this long before asking about the same locked item again.");
		gameplay.add(toggle(right, y, "Skip creative", () -> config.skipCreativeAndSpectator, v -> config.skipCreativeAndSpectator = v,
				"Don't challenge players in creative or spectator mode."));
		y += ROW;

		// Ignored items (full width, or half width next to the reset button in singleplayer)
		MinecraftServer sp = Minecraft.getInstance().getSingleplayerServer();
		net.minecraft.client.player.LocalPlayer player = Minecraft.getInstance().player;
		boolean canReset = sp != null && player != null;
		ignoredBox = new EditBox(this.font, left, y, canReset ? BUTTON_W : BUTTON_W * 2 + GAP, BUTTON_H, Component.literal("Ignored items"));
		ignoredBox.setMaxLength(2000);
		ignoredBox.setValue(String.join(", ", config.ignoredItems));
		ignoredBox.setTooltip(Tooltip.create(Component.literal(
				"Items that are never challenged, separated by commas, e.g. minecraft:dirt, minecraft:cobblestone")));
		ignoredBox.active = serverEditable;
		ignoredBox.setEditable(serverEditable);
		addRenderableWidget(ignoredBox);

		// Reset unlocks (only in your own singleplayer world)
		if (canReset) {
			java.util.UUID uuid = player.getUUID();
			int count = dev.speakorlose.UnlockStore.count(uuid);
			final boolean[] armed = {false};
			addRenderableWidget(Button.builder(Component.literal("Reset my unlocks (" + count + ")"), b -> {
						if (!armed[0]) {
							armed[0] = true;
							b.setMessage(Component.literal("Click again to confirm"));
						} else {
							sp.execute(() -> ChallengeManager.resetUnlocks(uuid));
							b.setMessage(Component.literal("Unlocks reset"));
							b.active = false;
						}
					})
					.pos(right, y).size(BUTTON_W, BUTTON_H)
					.tooltip(Tooltip.create(Component.literal("Lock every item again in this world. Can't be undone.")))
					.build());
		}
		y += ROW;

		if (!serverEditable) {
			Tooltip locked = Tooltip.create(Component.literal("Set by this server's config/speakorlose.json"));
			for (Button b : gameplay) {
				b.active = false;
				b.setTooltip(locked);
			}
		}

		// Client section
		clientLabelY = y;
		y += 12;
		ModelInstaller.ClientConfig client = ModelInstaller.config();
		List<String> mics = new ArrayList<>();
		mics.add("");
		mics.addAll(Microphone.devices());
		if (!mics.contains(client.microphone)) mics.add(client.microphone);
		cycle(left, y, "Mic", mics, () -> client.microphone, v -> client.microphone = v,
				v -> v.isBlank() ? "Default" : this.font.plainSubstrByWidth(v, BUTTON_W - 40),
				"Which microphone to listen on. Click to switch devices.");
		addRenderableWidget(Button.builder(Component.literal("Test microphone..."), b -> {
					ModelInstaller.saveClientConfig();
					this.minecraft.gui.setScreen(new MicTestScreen(this, testLanguage()));
				})
				.pos(right, y).size(BUTTON_W, BUTTON_H)
				.tooltip(Tooltip.create(Component.literal("Check the mic level and see what the speech model hears.")))
				.build());
		y += ROW;
		cycle(left, y, "Model quality", List.of("small", "large"), () -> client.modelQuality, v -> client.modelQuality = v,
				v -> "large".equals(v) ? "Large" : "Small",
				"Small: fast, ~50 MB. Large: much better at hearing you correctly, but a 1–2 GB download per language "
						+ "(downloads in the background; Small is used until it's ready).");
		addRenderableWidget(onOffButton(right, y, "Mic boost",
				() -> client.micBoost, v -> client.micBoost = v,
				"Filters out hum and background rumble, and raises quiet microphones to a normal level."));
		y += ROW;
		addRenderableWidget(onOffButton(left, y, "Auto-download models",
				() -> client.autoDownloadModels, v -> client.autoDownloadModels = v,
				"Download missing speech models from alphacephei.com (the Vosk project) when a new language comes up."));
		addRenderableWidget(Button.builder(Component.literal("Open models folder"), b -> openModelsFolder())
				.pos(right, y).size(BUTTON_W, BUTTON_H)
				.tooltip(Tooltip.create(Component.literal("Put extra Vosk models here, one folder per language code.")))
				.build());

		// Done
		addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
				.pos(this.width / 2 - 100, this.height - 27).size(200, BUTTON_H)
				.build());
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		int left = this.width / 2 - BUTTON_W - GAP / 2;
		graphics.centeredText(this.font, this.title.getString(), this.width / 2, 12, HEADER_COLOR);
		graphics.text(this.font, serverEditable ? "Gameplay" : "Gameplay (set by server)", left, gameplayLabelY, serverEditable ? HEADER_COLOR : NOTE_COLOR);
		graphics.text(this.font, "This computer", left, clientLabelY, HEADER_COLOR);
	}

	@Override
	public void onClose() {
		if (serverEditable) {
			config.ignoredItems = new ArrayList<>(Arrays.stream(ignoredBox.getValue().split(","))
					.map(String::trim).filter(s -> !s.isEmpty())
					.map(s -> s.contains(":") ? s : "minecraft:" + s)
					.toList());
			config.save();
			MinecraftServer server = Minecraft.getInstance().getSingleplayerServer();
			if (server != null) {
				ModConfig applied = ModConfig.load();
				server.execute(() -> ChallengeManager.applyConfig(applied));
			}
		}
		ModelInstaller.saveClientConfig();
		this.minecraft.gui.setScreen(parent);
	}

	// ------------------------------------------------------------------ helpers

	private Button languagesButton;

	private Component languagesLabel() {
		List<String> names = config.languages.stream().map(Translations::languageName).toList();
		String joined = String.join(", ", names);
		if (this.font != null && this.font.width("Languages: " + joined) > BUTTON_W - 10) {
			joined = names.size() + " selected";
		}
		return Component.literal("Languages: " + joined);
	}

	private void refreshLanguages() {
		if (languagesButton != null) languagesButton.setMessage(languagesLabel());
	}

	private Button toggle(int x, int y, String label, Supplier<Boolean> get, Consumer<Boolean> set, String tip) {
		return addRenderableWidget(onOffButton(x, y, label, get, set, tip));
	}

	/** A vanilla-style "Label: ON/OFF" button. */
	static Button onOffButton(int x, int y, String label, Supplier<Boolean> get, Consumer<Boolean> set, String tip) {
		return Button.builder(onOff(label, get.get()), b -> {
					set.accept(!get.get());
					b.setMessage(onOff(label, get.get()));
				})
				.pos(x, y).size(BUTTON_W, BUTTON_H)
				.tooltip(Tooltip.create(Component.literal(tip)))
				.build();
	}

	private static Component onOff(String label, boolean value) {
		return Component.literal(label + ": ").append(value ? CommonComponents.OPTION_ON : CommonComponents.OPTION_OFF);
	}

	private Button cycle(int x, int y, String label, List<String> values, Supplier<String> get, Consumer<String> set,
						 java.util.function.Function<String, String> display, String tip) {
		return addRenderableWidget(Button.builder(Component.literal(label + ": " + display.apply(get.get())), b -> {
					int i = (values.indexOf(get.get()) + 1) % values.size();
					set.accept(values.get(i));
					b.setMessage(Component.literal(label + ": " + display.apply(get.get())));
				})
				.pos(x, y).size(BUTTON_W, BUTTON_H)
				.tooltip(Tooltip.create(Component.literal(tip)))
				.build());
	}

	private void addSlider(List<Button> lockList, int x, int y, String label, int min, int max, int step,
						   Supplier<Integer> get, Consumer<Integer> set, IntFunction<String> format, String tip) {
		IntSlider slider = new IntSlider(x, y, label, min, max, step, get.get(), set, format);
		slider.setTooltip(Tooltip.create(Component.literal(serverEditable ? tip : "Set by this server's config/speakorlose.json")));
		slider.active = serverEditable;
		addRenderableWidget(slider);
	}

	/** First chosen language that has (or bundles) a speech model, for the mic test. */
	private String testLanguage() {
		for (String lang : config.languages) {
			if (SpeechListener.hasModel(lang) || ModelInstaller.isBundled(lang)) return lang;
		}
		return config.languages.isEmpty() ? "de_de" : config.languages.get(0);
	}

	private void openModelsFolder() {
		try {
			java.nio.file.Path dir = SpeechListener.modelsDir().toAbsolutePath();
			java.nio.file.Files.createDirectories(dir);
			String os = System.getProperty("os.name", "").toLowerCase(java.util.Locale.ROOT);
			String[] cmd = os.contains("win") ? new String[] {"explorer", dir.toString()}
					: os.contains("mac") ? new String[] {"open", dir.toString()}
					: new String[] {"xdg-open", dir.toString()};
			new ProcessBuilder(cmd).start();
		} catch (Exception e) {
			dev.speakorlose.SpeakOrLose.LOGGER.warn("Could not open {}", SpeechListener.modelsDir(), e);
		}
	}

	/** Vanilla slider that snaps to whole-number steps. */
	private static final class IntSlider extends AbstractSliderButton {
		private final String label;
		private final int min, max, step;
		private final Consumer<Integer> set;
		private final IntFunction<String> format;

		IntSlider(int x, int y, String label, int min, int max, int step, int current, Consumer<Integer> set, IntFunction<String> format) {
			super(x, y, BUTTON_W, BUTTON_H, Component.empty(), (double) (Math.clamp(current, min, max) - min) / (max - min));
			this.label = label;
			this.min = min;
			this.max = max;
			this.step = step;
			this.set = set;
			this.format = format;
			updateMessage();
		}

		private int current() {
			int raw = (int) Math.round(min + value * (max - min));
			return Math.clamp(Math.round((float) raw / step) * step, min, max);
		}

		@Override
		protected void updateMessage() {
			setMessage(Component.literal(label + ": " + format.apply(current())));
		}

		@Override
		protected void applyValue() {
			set.accept(current());
		}
	}

	/** Sub-screen: one ON/OFF button per language, in two columns. */
	private static final class LanguagesScreen extends Screen {
		private final Screen parent;
		private final ModConfig config;
		private final Runnable onDone;

		LanguagesScreen(Screen parent, ModConfig config, Runnable onDone) {
			super(Component.literal("Challenge Languages"));
			this.parent = parent;
			this.config = config;
			this.onDone = onDone;
		}

		@Override
		protected void init() {
			List<String> langs = ModelInstaller.knownLanguages();
			int left = this.width / 2 - BUTTON_W - GAP / 2;
			int right = this.width / 2 + GAP / 2;
			for (int i = 0; i < langs.size(); i++) {
				String code = langs.get(i);
				int x = i % 2 == 0 ? left : right;
				int y = 32 + (i / 2) * ROW;
				String bundled = ModelInstaller.isBundled(code) ? " · bundled"
						: SpeechListener.hasModel(code) ? " · installed" : " · downloads on first use";
				addRenderableWidget(onOffButton(x, y, Translations.languageName(code) + " (" + code + ")",
						() -> config.languages.contains(code),
						on -> {
							if (on) {
								if (!config.languages.contains(code)) config.languages.add(code);
							} else if (config.languages.size() > 1) {
								config.languages.remove(code); // always keep at least one
							}
						},
						Translations.languageName(code) + bundled));
			}
			addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
					.pos(this.width / 2 - 100, this.height - 27).size(200, BUTTON_H)
					.build());
		}

		@Override
		public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
			super.extractRenderState(graphics, mouseX, mouseY, delta);
			graphics.centeredText(this.font, this.title.getString(), this.width / 2, 12, HEADER_COLOR);
		}

		@Override
		public void onClose() {
			onDone.run();
			this.minecraft.gui.setScreen(parent);
		}
	}
}
