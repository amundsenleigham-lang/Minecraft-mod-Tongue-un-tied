package dev.speakorlose.client;

import dev.speakorlose.SpeakOrLose;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Line;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import java.util.ArrayList;
import java.util.List;

/**
 * Finds and opens a microphone. Many devices (especially on Windows) refuse 16 kHz mono, so this
 * tries several common formats; Vosk resamples whatever rate we give it, and stereo is mixed down.
 */
public final class Microphone {
	/**
	 * Formats to try, most preferred first: {sampleRate, channels}.
	 * Native device rates come first: Java's own conversion down to 16 kHz is low quality,
	 * while Vosk resamples cleanly itself.
	 */
	private static final float[][] FORMATS = {
			{48000, 1}, {44100, 1}, {48000, 2}, {44100, 2},
			{32000, 1}, {22050, 1}, {16000, 1}, {16000, 2}
	};

	private Microphone() {}

	public record Opened(TargetDataLine line, float sampleRate, int channels, String deviceName) {}

	/** Names of input devices that can record. */
	public static List<String> devices() {
		List<String> names = new ArrayList<>();
		Line.Info wanted = new Line.Info(TargetDataLine.class);
		for (Mixer.Info info : AudioSystem.getMixerInfo()) {
			try {
				Mixer mixer = AudioSystem.getMixer(info);
				if (mixer.isLineSupported(wanted) && !names.contains(info.getName())) names.add(info.getName());
			} catch (Exception ignored) {
			}
		}
		return names;
	}

	/**
	 * Opens the named device, or the system default when the name is blank or not found.
	 * Returns null if nothing could be opened; the reason is in the log.
	 */
	public static Opened open(String preferred) {
		List<Mixer.Info> order = new ArrayList<>();
		if (preferred != null && !preferred.isBlank()) {
			for (Mixer.Info info : AudioSystem.getMixerInfo()) {
				if (info.getName().equals(preferred)) order.add(info);
			}
		}
		order.add(null); // system default

		Exception last = null;
		for (Mixer.Info mixerInfo : order) {
			for (float[] f : FORMATS) {
				AudioFormat format = new AudioFormat(f[0], 16, (int) f[1], true, false);
				DataLine.Info lineInfo = new DataLine.Info(TargetDataLine.class, format);
				try {
					TargetDataLine line = mixerInfo == null
							? (TargetDataLine) AudioSystem.getLine(lineInfo)
							: (TargetDataLine) AudioSystem.getMixer(mixerInfo).getLine(lineInfo);
					line.open(format);
					String name = mixerInfo == null ? "Default microphone" : mixerInfo.getName();
					SpeakOrLose.LOGGER.info("Microphone opened: {} at {} Hz, {} channel(s)", name, (int) f[0], (int) f[1]);
					return new Opened(line, f[0], (int) f[1], name);
				} catch (Exception e) {
					last = e;
				}
			}
		}
		SpeakOrLose.LOGGER.error("Could not open any microphone. Devices found: {}", devices(), last);
		return null;
	}

	/** Mixes 16-bit little-endian stereo down to mono in place; returns the new byte count. */
	static int toMono(byte[] buf, int n) {
		int frames = n / 4;
		for (int i = 0; i < frames; i++) {
			int l = (short) ((buf[i * 4] & 0xFF) | (buf[i * 4 + 1] << 8));
			int r = (short) ((buf[i * 4 + 2] & 0xFF) | (buf[i * 4 + 3] << 8));
			int m = (l + r) / 2;
			buf[i * 2] = (byte) m;
			buf[i * 2 + 1] = (byte) (m >> 8);
		}
		return frames * 2;
	}

	/** Loudness 0..1 of 16-bit little-endian mono audio, for the level meter. */
	static float level(byte[] buf, int n) {
		long sum = 0;
		int samples = n / 2;
		for (int i = 0; i < samples; i++) {
			int s = (short) ((buf[i * 2] & 0xFF) | (buf[i * 2 + 1] << 8));
			sum += (long) s * s;
		}
		if (samples == 0) return 0f;
		double rms = Math.sqrt((double) sum / samples) / 32768.0;
		return (float) Math.min(1.0, rms * 4); // speech is quiet; scale so normal talking fills most of the bar
	}
}
