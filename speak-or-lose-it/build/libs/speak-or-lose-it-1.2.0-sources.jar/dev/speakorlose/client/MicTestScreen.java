package dev.speakorlose.client;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

/**
 * "Test microphone": shows a live input level and what the recognizer hears, so players can
 * check their mic and model before playing. Uses vanilla buttons only.
 */
public class MicTestScreen extends Screen {
	private static final int WHITE = 0xFFFFFFFF;
	private static final int MUTED = 0xFFA0A0A0;
	private static final int GOOD = 0xFF7BE07B;
	private static final int BAD = 0xFFFF6B6B;

	private final Screen parent;
	private final String language;
	private volatile String heard = "";
	private volatile String status = "Starting…";
	private volatile int statusColor = MUTED;
	private volatile boolean running;
	private Button againButton;

	public MicTestScreen(Screen parent, String language) {
		super(Component.literal("Test Microphone"));
		this.parent = parent;
		this.language = language;
	}

	@Override
	protected void init() {
		againButton = addRenderableWidget(Button.builder(Component.literal("Test again"), b -> startTest())
				.pos(this.width / 2 - 154, this.height - 27).size(150, 20).build());
		addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
				.pos(this.width / 2 + 4, this.height - 27).size(150, 20).build());
		if (!running) startTest();
	}

	private void startTest() {
		if (running) return;
		running = true;
		heard = "";
		if (!SpeechListener.hasModel(language) && !ModelInstaller.isBundled(language)) {
			ModelInstaller.requestDownload(language);
			status = "No " + Translations.languageName(language) + " speech model yet — downloading. Try again in a minute.";
			statusColor = MUTED;
			running = false;
			return;
		}
		status = "Loading… then say something in " + Translations.languageName(language) + ".";
		statusColor = MUTED;
		SpeechListener.listen(language, 15_000, null, 2.0, new SpeechListener.Listener() {
			@Override
			public void onStart() {
				status = "Listening… say something in " + Translations.languageName(language) + ".";
			}

			@Override
			public void onLive(String text, double bestScore) {
				heard = text;
			}

			@Override
			public void onFinish(SpeechListener.Outcome outcome, String text, double bestScore) {
				running = false;
				switch (outcome) {
					case DONE -> {
						heard = text;
						status = text.isBlank() ? "Didn't hear any words. Check the level bar moved, or pick another microphone."
								: "Working! Your mic and speech model are ready.";
						statusColor = text.isBlank() ? BAD : GOOD;
					}
					case NO_MIC -> {
						status = "Couldn't open the microphone. Check Windows Settings → Privacy → Microphone → \"Let desktop apps access your microphone\".";
						statusColor = BAD;
					}
					case NO_MODEL -> {
						status = "No speech model installed for " + language + ".";
						statusColor = BAD;
					}
					default -> {
						status = "Speech recognition error — see the game log.";
						statusColor = BAD;
					}
				}
			}
		});
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
		super.extractRenderState(graphics, mouseX, mouseY, delta);
		int cx = this.width / 2;
		graphics.centeredText(this.font, this.title.getString(), cx, 12, WHITE);

		String device = ModelInstaller.config().microphone;
		graphics.centeredText(this.font, "Device: " + (device == null || device.isBlank() ? "Default microphone" : device)
				+ "  ·  Model: " + (SpeechListener.activeModelDir(language).equals(SpeechListener.largeModelDir(language)) ? "Large" : "Small"), cx, 36, MUTED);

		// Level bar
		int barW = 200, barX = cx - barW / 2, barY = 56;
		graphics.fill(barX - 1, barY - 1, barX + barW + 1, barY + 11, 0xFF000000);
		graphics.fill(barX, barY, barX + barW, barY + 10, 0xFF333333);
		int filled = Math.round(barW * Math.clamp(SpeechListener.level, 0f, 1f));
		graphics.fill(barX, barY, barX + filled, barY + 10, GOOD);
		graphics.centeredText(this.font, "Input level", cx, barY + 14, MUTED);

		graphics.centeredText(this.font, "Heard:", cx, 92, MUTED);
		String shown = heard.isBlank() ? "—" : heard;
		graphics.centeredText(this.font, this.font.plainSubstrByWidth(shown, this.width - 40), cx, 104, WHITE);

		int y = 128;
		for (String line : wrap(status, Math.min(300, this.width - 40))) {
			graphics.centeredText(this.font, line, cx, y, statusColor);
			y += 11;
		}

		if (againButton != null) againButton.active = !running;
	}

	/** Simple word wrap using the font's widths. */
	private java.util.List<String> wrap(String text, int maxWidth) {
		java.util.List<String> lines = new java.util.ArrayList<>();
		StringBuilder line = new StringBuilder();
		for (String word : text.split(" ")) {
			String candidate = line.isEmpty() ? word : line + " " + word;
			if (this.font.width(candidate) > maxWidth && !line.isEmpty()) {
				lines.add(line.toString());
				line = new StringBuilder(word);
			} else {
				line = new StringBuilder(candidate);
			}
		}
		if (!line.isEmpty()) lines.add(line.toString());
		return lines;
	}

	@Override
	public void onClose() {
		SpeechListener.cancel();
		this.minecraft.gui.setScreen(parent);
	}
}
