package dev.speakorlose.client;

/**
 * Light clean-up before speech recognition, applied to 16-bit little-endian mono audio in place:
 * <ul>
 *   <li>a 2-pole high-pass filter (80 Hz) that removes mains hum, desk thumps and DC offset;</li>
 *   <li>automatic gain that brings quiet microphones up to a normal speaking level;</li>
 *   <li>a soft limiter so loud speech or the boost never clips.</li>
 * </ul>
 * One instance per recording, because it keeps filter state between buffers.
 */
final class AudioCleanup {
	private static final double TARGET_RMS = 0.12;   // about -18 dBFS, a comfortable level for the recognizer
	private static final double MAX_GAIN = 10.0;
	private static final double NOISE_FLOOR = 0.004; // don't boost silence/background noise

	private static final double CUTOFF_HZ = 80.0;
	private static final double LIMIT_KNEE = 0.7;   // below this the signal passes untouched

	// Biquad high-pass (Butterworth, Q = 0.707) coefficients and state.
	private final double b0, b1, b2, a1, a2;
	private double x1, x2, y1, y2;
	private final boolean boost;
	private double gain = 1.0;

	AudioCleanup(float sampleRate, boolean boost) {
		double w0 = 2 * Math.PI * CUTOFF_HZ / sampleRate;
		double alpha = Math.sin(w0) / (2 * Math.sqrt(0.5));
		double cos = Math.cos(w0);
		double a0 = 1 + alpha;
		this.b0 = (1 + cos) / 2 / a0;
		this.b1 = -(1 + cos) / a0;
		this.b2 = (1 + cos) / 2 / a0;
		this.a1 = -2 * cos / a0;
		this.a2 = (1 - alpha) / a0;
		this.boost = boost;
	}

	void process(byte[] buf, int n) {
		int samples = n / 2;
		if (samples == 0) return;

		// Pass 1: high-pass filter, and measure the loudness of this buffer.
		double[] x = new double[samples];
		double sumSq = 0;
		for (int i = 0; i < samples; i++) {
			double in = (short) ((buf[i * 2] & 0xFF) | (buf[i * 2 + 1] << 8)) / 32768.0;
			double out = b0 * in + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
			x2 = x1; x1 = in;
			y2 = y1; y1 = out;
			x[i] = out;
			sumSq += out * out;
		}
		double rms = Math.sqrt(sumSq / samples);

		// Gain: rise slowly toward the target while someone is talking, drop fast if it gets loud.
		if (boost && rms > NOISE_FLOOR) {
			double wanted = Math.min(MAX_GAIN, Math.max(1.0, TARGET_RMS / rms));
			gain += (wanted - gain) * (wanted < gain ? 0.5 : 0.15);
		} else if (!boost) {
			gain = 1.0;
		}

		// Pass 2: apply gain with a soft limiter, write back.
		for (int i = 0; i < samples; i++) {
			double v = x[i] * gain;
			double mag = Math.abs(v);
			if (mag > LIMIT_KNEE) { // soft knee: compress only the loud part, never exceed 1.0
				double over = (mag - LIMIT_KNEE) / (1 - LIMIT_KNEE);
				v = Math.signum(v) * (LIMIT_KNEE + (1 - LIMIT_KNEE) * Math.tanh(over));
			}
			int s = (int) Math.round(Math.clamp(v, -1.0, 1.0) * 32767);
			buf[i * 2] = (byte) s;
			buf[i * 2 + 1] = (byte) (s >> 8);
		}
	}
}
