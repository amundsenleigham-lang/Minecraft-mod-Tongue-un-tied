package dev.speakorlose.client;

import java.text.Normalizer;
import java.util.Locale;

/** Compares what the recognizer heard with the target word. */
public final class Scoring {
	private Scoring() {}

	/** Lower-case, strip accents and punctuation, collapse whitespace. Keeps CJK characters. */
	public static String normalize(String s) {
		String n = s.toLowerCase(Locale.ROOT).replace("ß", "ss");
		n = Normalizer.normalize(n, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
		n = n.replaceAll("[^\\p{L}\\p{N}]+", " ").trim().replaceAll("\\s+", " ");
		return n;
	}

	/**
	 * Similarity in 0..1. Spaces are ignored (recognizers often split or join compound words),
	 * and if the player said extra words, the best-matching run of words is used.
	 */
	public static float score(String target, String heard) {
		String t = normalize(target);
		String h = normalize(heard);
		if (t.isEmpty() || h.isEmpty()) return 0f;

		String tCompact = t.replace(" ", "");
		float best = similarity(tCompact, h.replace(" ", ""));

		String[] words = h.split(" ");
		for (int start = 0; start < words.length; start++) {
			StringBuilder run = new StringBuilder();
			for (int end = start; end < words.length; end++) {
				run.append(words[end]);
				best = Math.max(best, similarity(tCompact, run.toString()));
				if (run.length() > tCompact.length() * 2) break;
			}
		}
		return best;
	}

	private static float similarity(String a, String b) {
		int max = Math.max(a.length(), b.length());
		if (max == 0) return 1f;
		return 1f - (float) levenshtein(a, b) / max;
	}

	private static int levenshtein(String a, String b) {
		int[] prev = new int[b.length() + 1];
		int[] cur = new int[b.length() + 1];
		for (int j = 0; j <= b.length(); j++) prev[j] = j;
		for (int i = 1; i <= a.length(); i++) {
			cur[0] = i;
			for (int j = 1; j <= b.length(); j++) {
				int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
				cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
			}
			int[] tmp = prev; prev = cur; cur = tmp;
		}
		return prev[b.length()];
	}
}
