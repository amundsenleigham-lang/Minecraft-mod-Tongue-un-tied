package dev.speakorlose;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Server-side settings, stored in config/speakorlose.json.
 * The file is created with defaults on first launch and re-read every time a world/server starts.
 */
public final class ModConfig {

	/** Language codes to challenge in. One is picked at random per challenge. */
	public List<String> languages = new ArrayList<>(List.of("de_de"));

	/*
	 * How it works: every item starts LOCKED. Whenever a locked item is in your inventory
	 * (picked up, crafted, smelted, from a chest, traded... any source) you're challenged.
	 * Say it right and it's UNLOCKED for good in that world. Fail and it's deleted, and it
	 * stays locked, so you'll be challenged again next time you get it.
	 */

	/** Every {@link #timerSeconds}, quiz a random item from your inventory, even unlocked ones. Failing re-locks it. */
	public boolean triggerOnTimer = false;
	public int timerSeconds = 90;

	/** Seconds to wait before challenging a locked item again (after a fail, or if you still hold some). */
	public int retryDelaySeconds = 3;

	/** Seconds the player has to say the word. */
	public int answerSeconds = 8;

	/** How close the pronunciation must be (0.0 - 1.0). 0.75 = 75% match. */
	public float passThreshold = 0.75f;

	/** What to delete on a fail: "all" (every stack of that item), "stack" (one stack) or "one" (a single item). */
	public String deleteMode = "all";

	/** Skip players in creative or spectator mode. */
	public boolean skipCreativeAndSpectator = true;

	/** Items that are never challenged, e.g. "minecraft:dirt". */
	public List<String> ignoredItems = new ArrayList<>();

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public static Path path() {
		return FabricLoader.getInstance().getConfigDir().resolve("speakorlose.json");
	}

	public static ModConfig load() {
		Path path = path();
		ModConfig config = new ModConfig();
		try {
			if (Files.exists(path)) {
				try (Reader reader = Files.newBufferedReader(path)) {
					ModConfig read = GSON.fromJson(reader, ModConfig.class);
					if (read != null) config = read;
				}
			}
			config.sanitize();
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path)) {
				GSON.toJson(config, writer);
			}
		} catch (Exception e) {
			SpeakOrLose.LOGGER.error("Could not read {}, using defaults", path, e);
			config = new ModConfig();
		}
		return config;
	}

	/** Write these settings to disk (after clamping them to valid ranges). */
	public void save() {
		sanitize();
		Path path = path();
		try {
			Files.createDirectories(path.getParent());
			try (Writer writer = Files.newBufferedWriter(path)) {
				GSON.toJson(this, writer);
			}
		} catch (Exception e) {
			SpeakOrLose.LOGGER.error("Could not save {}", path, e);
		}
	}

	public void sanitize() {
		if (languages == null || languages.isEmpty()) languages = new ArrayList<>(List.of("de_de"));
		languages.replaceAll(s -> s.toLowerCase().trim());
		if (ignoredItems == null) ignoredItems = new ArrayList<>();
		answerSeconds = Math.clamp(answerSeconds, 2, 60);
		timerSeconds = Math.max(5, timerSeconds);
		passThreshold = Math.clamp(passThreshold, 0.05f, 1.0f);
		retryDelaySeconds = Math.clamp(retryDelaySeconds, 1, 300);
		if (deleteMode == null || !List.of("all", "stack", "one").contains(deleteMode)) deleteMode = "all";
	}
}
