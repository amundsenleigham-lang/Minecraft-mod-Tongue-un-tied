package dev.speakorlose.net;

import dev.speakorlose.SpeakOrLose;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Server -> client: "say this item's name in this language".
 *
 * @param id             challenge id, echoed back in the result
 * @param itemId         registry id of the item (e.g. minecraft:wheat)
 * @param translationKey the item's translation key (e.g. item.minecraft.wheat)
 * @param language       Minecraft language code to challenge in (e.g. de_de)
 * @param seconds        how long the player has to answer
 * @param threshold      similarity (0..1) needed to pass
 */
public record ChallengePayload(int id, String itemId, String translationKey, String language, int seconds, float threshold)
		implements CustomPacketPayload {

	public static final Type<ChallengePayload> TYPE = new Type<>(SpeakOrLose.id("challenge"));
	public static final StreamCodec<FriendlyByteBuf, ChallengePayload> CODEC =
			CustomPacketPayload.codec(ChallengePayload::write, ChallengePayload::new);

	private ChallengePayload(FriendlyByteBuf buf) {
		this(buf.readVarInt(), buf.readUtf(), buf.readUtf(), buf.readUtf(), buf.readVarInt(), buf.readFloat());
	}

	private void write(FriendlyByteBuf buf) {
		buf.writeVarInt(id);
		buf.writeUtf(itemId);
		buf.writeUtf(translationKey);
		buf.writeUtf(language);
		buf.writeVarInt(seconds);
		buf.writeFloat(threshold);
	}

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
