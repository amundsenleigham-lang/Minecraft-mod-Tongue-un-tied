package dev.speakorlose.net;

import dev.speakorlose.SpeakOrLose;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * Client -> server: how well the player said the word.
 *
 * @param id     challenge id from {@link ChallengePayload}
 * @param score  similarity 0..1, or a negative value if the challenge could not be run
 *               (no speech model installed, no microphone). Negative results never delete items.
 * @param heard  what the recognizer heard, for the chat message
 */
public record ResultPayload(int id, float score, String heard) implements CustomPacketPayload {

	public static final float SKIPPED = -1f;

	public static final Type<ResultPayload> TYPE = new Type<>(SpeakOrLose.id("result"));
	public static final StreamCodec<FriendlyByteBuf, ResultPayload> CODEC =
			CustomPacketPayload.codec(ResultPayload::write, ResultPayload::new);

	private ResultPayload(FriendlyByteBuf buf) {
		this(buf.readVarInt(), buf.readFloat(), buf.readUtf(256));
	}

	private void write(FriendlyByteBuf buf) {
		buf.writeVarInt(id);
		buf.writeFloat(score);
		buf.writeUtf(heard.length() > 256 ? heard.substring(0, 256) : heard, 256);
	}

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
