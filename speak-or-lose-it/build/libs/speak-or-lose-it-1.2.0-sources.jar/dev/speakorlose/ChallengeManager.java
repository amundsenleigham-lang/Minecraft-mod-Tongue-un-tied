package dev.speakorlose;

import dev.speakorlose.net.ChallengePayload;
import dev.speakorlose.net.ResultPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Server-side brain.
 *
 * Every item starts locked. Whenever a locked item is in a player's inventory — however it got
 * there — they're challenged on it. Passing unlocks it for good (saved in the world folder by
 * {@link UnlockStore}). Failing deletes it and it stays locked.
 */
public final class ChallengeManager {

	/** How often (in ticks) inventories are scanned for locked items. */
	private static final int SCAN_INTERVAL = 5;
	/** Extra time allowed for the client's reply before the challenge is dropped (no deletion). */
	private static final int REPLY_GRACE_TICKS = 20 * 20; // leaves room for a large speech model to load
	/** After a skipped challenge (no mic / no model / no reply), wait this long before asking again. */
	private static final int SKIP_BACKOFF_TICKS = 20 * 30;
	/** Save unlocks at most this often (they're also saved when the world closes). */
	private static final int SAVE_INTERVAL = 20 * 10;

	private static ModConfig config = new ModConfig();
	private static final Map<UUID, PlayerState> STATES = new HashMap<>();
	private static int nextChallengeId = 1;
	private static long tick = 0;

	private ChallengeManager() {}

	private static final class PlayerState {
		final Map<Item, Long> retryAt = new HashMap<>();
		Active active;
		long nextTimerTick;
	}

	/** @param review true when started by the random timer on a possibly-unlocked item */
	private record Active(int id, Item item, boolean review, long deadlineTick) {}

	public static ModConfig config() {
		return config;
	}

	public static void reloadConfig() {
		config = ModConfig.load();
		SpeakOrLose.LOGGER.info("Speak or Lose It: languages={}, timer={}, threshold={}",
				config.languages, config.triggerOnTimer, config.passThreshold);
	}

	/** Apply new settings immediately (used by the in-game settings screen in singleplayer). Call on the server thread. */
	public static void applyConfig(ModConfig newConfig) {
		config = newConfig;
		for (PlayerState state : STATES.values()) {
			state.nextTimerTick = Math.min(state.nextTimerTick, tick + config.timerSeconds * 20L);
		}
	}

	public static void onServerStarted(MinecraftServer server) {
		UnlockStore.load(server);
	}

	public static void onServerStopping(MinecraftServer server) {
		UnlockStore.saveIfDirty();
		STATES.clear();
	}

	public static void onJoin(ServerPlayer player) {
		PlayerState state = new PlayerState();
		state.nextTimerTick = tick + config.timerSeconds * 20L;
		// Give the client a moment to load in before the first challenge.
		long start = tick + 40;
		STATES.put(player.getUUID(), state);
		state.retryAt.put(null, start);
	}

	public static void onLeave(ServerPlayer player) {
		STATES.remove(player.getUUID());
	}

	public static void onServerTick(MinecraftServer server) {
		tick++;
		if (tick % SAVE_INTERVAL == 0) UnlockStore.saveIfDirty();

		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			PlayerState state = STATES.get(player.getUUID());
			if (state == null) continue;
			if (!ServerPlayNetworking.canSend(player, ChallengePayload.TYPE)) continue; // no mod on client: never punish
			if (state.retryAt.getOrDefault(null, 0L) > tick) continue; // join grace period

			if (state.active != null) {
				if (tick > state.active.deadlineTick() + REPLY_GRACE_TICKS) {
					// Client never answered: drop it without deleting anything, ask again later.
					state.retryAt.put(state.active.item(), tick + SKIP_BACKOFF_TICKS);
					state.active = null;
				}
				continue;
			}

			if (config.skipCreativeAndSpectator && (player.isCreative() || player.isSpectator())) continue;

			if (config.triggerOnTimer && tick >= state.nextTimerTick) {
				state.nextTimerTick = tick + config.timerSeconds * 20L;
				Item random = randomInventoryItem(player);
				if (random != null) {
					start(player, state, random, true);
					continue;
				}
			}

			if (tick % SCAN_INTERVAL == 0) {
				Item locked = firstLockedItem(player, state);
				if (locked != null) start(player, state, locked, false);
			}
		}
	}

	private static String id(Item item) {
		return BuiltInRegistries.ITEM.getKey(item).toString();
	}

	private static boolean challengeable(Item item) {
		return !config.ignoredItems.contains(id(item));
	}

	/** First locked, non-ignored item in the inventory that isn't waiting out a retry delay. */
	private static Item firstLockedItem(ServerPlayer player, PlayerState state) {
		Inventory inv = player.getInventory();
		UUID uuid = player.getUUID();
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack stack = inv.getItem(i);
			if (stack.isEmpty()) continue;
			Item item = stack.getItem();
			if (!challengeable(item)) continue;
			if (UnlockStore.isUnlocked(uuid, id(item))) continue;
			if (state.retryAt.getOrDefault(item, 0L) > tick) continue;
			return item;
		}
		return null;
	}

	private static void start(ServerPlayer player, PlayerState state, Item item, boolean review) {
		int id = nextChallengeId++;
		String language = config.languages.get(ThreadLocalRandom.current().nextInt(config.languages.size()));
		state.active = new Active(id, item, review, tick + config.answerSeconds * 20L);
		ServerPlayNetworking.send(player, new ChallengePayload(
				id, id(item), item.getDescriptionId(), language, config.answerSeconds, config.passThreshold));
	}

	public static void onResult(ServerPlayer player, ResultPayload result) {
		PlayerState state = STATES.get(player.getUUID());
		if (state == null || state.active == null || state.active.id() != result.id()) return;
		Active active = state.active;
		Item item = active.item();
		state.active = null;

		if (result.score() < 0) {
			// Client couldn't run it (no model yet / no mic). Never punish; try again later.
			state.retryAt.put(item, tick + SKIP_BACKOFF_TICKS);
			return;
		}

		int percent = Math.round(Math.clamp(result.score(), 0f, 1f) * 100);
		Component itemName = Component.translatable(item.getDescriptionId());
		String heard = result.heard().isBlank() ? "nothing" : "\"" + result.heard() + "\"";
		state.retryAt.put(item, tick + config.retryDelaySeconds * 20L);

		if (result.score() >= config.passThreshold) {
			boolean wasUnlocked = UnlockStore.isUnlocked(player.getUUID(), id(item));
			UnlockStore.unlock(player.getUUID(), id(item));
			player.sendSystemMessage(Component.literal("✔ ").withStyle(ChatFormatting.GREEN)
					.append(itemName.copy().withStyle(ChatFormatting.WHITE))
					.append(Component.literal(wasUnlocked ? " — still got it (" + percent + "%)"
							: " unlocked (" + percent + "%)").withStyle(ChatFormatting.GRAY)));
		} else {
			UnlockStore.lock(player.getUUID(), id(item)); // a failed review re-locks it
			int removed = delete(player, item);
			player.sendSystemMessage(Component.literal("✘ ").withStyle(ChatFormatting.RED)
					.append(Component.literal("Heard " + heard + " (" + percent + "%) — lost " + removed + "× ").withStyle(ChatFormatting.GRAY))
					.append(itemName.copy().withStyle(ChatFormatting.WHITE))
					.append(Component.literal(". Still locked.").withStyle(ChatFormatting.GRAY)));
		}
	}

	/** Resets one player's unlocks (settings screen button in singleplayer). Call on the server thread. */
	public static void resetUnlocks(UUID player) {
		UnlockStore.reset(player);
		PlayerState state = STATES.get(player);
		if (state != null) state.retryAt.clear();
	}

	private static int delete(ServerPlayer player, Item item) {
		Inventory inv = player.getInventory();
		int removed = 0;
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack stack = inv.getItem(i);
			if (stack.isEmpty() || stack.getItem() != item) continue;
			switch (config.deleteMode) {
				case "one" -> {
					stack.shrink(1);
					if (stack.isEmpty()) inv.setItem(i, ItemStack.EMPTY);
					inv.setChanged();
					return 1;
				}
				case "stack" -> {
					removed = stack.getCount();
					inv.setItem(i, ItemStack.EMPTY);
					inv.setChanged();
					return removed;
				}
				default -> {
					removed += stack.getCount();
					inv.setItem(i, ItemStack.EMPTY);
				}
			}
		}
		// Also catch an item held on the cursor in an open inventory screen.
		ItemStack carried = player.containerMenu.getCarried();
		if ("all".equals(config.deleteMode) && !carried.isEmpty() && carried.getItem() == item) {
			removed += carried.getCount();
			player.containerMenu.setCarried(ItemStack.EMPTY);
		}
		inv.setChanged();
		return removed;
	}

	private static Item randomInventoryItem(ServerPlayer player) {
		Inventory inv = player.getInventory();
		List<Item> items = new ArrayList<>();
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack stack = inv.getItem(i);
			if (!stack.isEmpty() && challengeable(stack.getItem()) && !items.contains(stack.getItem())) items.add(stack.getItem());
		}
		return items.isEmpty() ? null : items.get(ThreadLocalRandom.current().nextInt(items.size()));
	}
}
