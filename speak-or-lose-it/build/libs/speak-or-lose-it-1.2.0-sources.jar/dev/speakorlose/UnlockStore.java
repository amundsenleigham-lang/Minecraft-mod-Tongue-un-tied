package dev.speakorlose;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Which items each player has unlocked (said correctly), saved inside the world folder as
 * speakorlose_unlocked.json, so it survives restarts and is separate for every world/server.
 */
public final class UnlockStore {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Type TYPE = new TypeToken<Map<String, Set<String>>>() {}.getType();

	private static final Map<UUID, Set<String>> UNLOCKED = new HashMap<>();
	private static Path file;
	private static boolean dirty;

	private UnlockStore() {}

	public static synchronized void load(MinecraftServer server) {
		UNLOCKED.clear();
		dirty = false;
		file = server.getWorldPath(LevelResource.ROOT).resolve("speakorlose_unlocked.json");
		if (!Files.exists(file)) return;
		try (Reader reader = Files.newBufferedReader(file)) {
			Map<String, Set<String>> raw = GSON.fromJson(reader, TYPE);
			if (raw != null) {
				raw.forEach((uuid, items) -> UNLOCKED.put(UUID.fromString(uuid), new HashSet<>(items)));
			}
			SpeakOrLose.LOGGER.info("Loaded Speak or Lose It unlocks for {} player(s)", UNLOCKED.size());
		} catch (Exception e) {
			SpeakOrLose.LOGGER.error("Could not read {}", file, e);
		}
	}

	/** Writes to disk if anything changed. Cheap to call often. */
	public static synchronized void saveIfDirty() {
		if (!dirty || file == null) return;
		Map<String, Set<String>> raw = new HashMap<>();
		UNLOCKED.forEach((uuid, items) -> raw.put(uuid.toString(), items));
		try {
			Path tmp = file.resolveSibling(file.getFileName() + ".tmp");
			try (Writer writer = Files.newBufferedWriter(tmp)) {
				GSON.toJson(raw, TYPE, writer);
			}
			Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
			dirty = false;
		} catch (Exception e) {
			SpeakOrLose.LOGGER.error("Could not save {}", file, e);
		}
	}

	public static synchronized boolean isUnlocked(UUID player, String itemId) {
		Set<String> set = UNLOCKED.get(player);
		return set != null && set.contains(itemId);
	}

	public static synchronized void unlock(UUID player, String itemId) {
		if (UNLOCKED.computeIfAbsent(player, k -> new HashSet<>()).add(itemId)) dirty = true;
	}

	public static synchronized void lock(UUID player, String itemId) {
		Set<String> set = UNLOCKED.get(player);
		if (set != null && set.remove(itemId)) dirty = true;
	}

	public static synchronized int count(UUID player) {
		Set<String> set = UNLOCKED.get(player);
		return set == null ? 0 : set.size();
	}

	public static synchronized void reset(UUID player) {
		if (UNLOCKED.remove(player) != null) dirty = true;
		saveIfDirty();
	}
}
